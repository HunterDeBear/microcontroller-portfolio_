#include <Arduino.h>
#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "BluetoothSerial.h"

// ================== Pin Configuration ==================
#define DHTPIN 19
#define DHTTYPE DHT22
#define FAN_PIN 25
#define BTN_ON 23
#define BTN_OFF 5
#define BTN_LCD 18
#define LED_BT 2

// ================== Objects ==================
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);
BluetoothSerial SerialBT;

// ================== System States ==================
bool systemOn = false;
uint8_t lcdMode = 0; // 0: Bluetooth, 1: System state, 2: Temperature
unsigned long lastLCDSwitch = 0;

// ================== PWM Configuration ==================
const int pwmChannel = 0;
const int pwmFreq = 100;   // 100 Hz
const int pwmResolution = 8; // 0–255

// ================== Fan Control Constants ==================
const float TEMP_MIN = 30.0f;     // Start ramping here
const float TEMP_MAX = 50.0f;     // Full speed here
const float HYSTERESIS = 1.5f;    // °C hysteresis band
const int MIN_ON_DUTY = 60;       // Minimum PWM to prevent stall
const float SMOOTH_ALPHA = 0.1f; // Smoothing speed (0.1–0.3)

// ================== Fan State Variables ==================
float dutyCurrent = 0.0f;   // Smoothed PWM duty
float filteredTemp = 25.0f; // Filtered DHT reading
unsigned long lastPrint = 0;

// ================== Function Prototypes ==================
void handleBluetoothCommands(String cmd);
void updateFanSmooth(float temp);
void updateLCD(float temp);

// ================== Setup ==================
void setup() {
  Serial.begin(115200);
  SerialBT.begin("ESP_FanController");

  pinMode(BTN_ON, INPUT_PULLUP);
  pinMode(BTN_OFF, INPUT_PULLUP);
  pinMode(BTN_LCD, INPUT_PULLUP);
  pinMode(LED_BT, OUTPUT);
  dht.begin();

  // LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("System Booting...");
  delay(1500);
  lcd.clear();

  // PWM Setup
  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(FAN_PIN, pwmChannel);
  ledcWrite(pwmChannel, 0); // Start OFF
}

// ================== Main Loop ==================
void loop() {
  // Bluetooth indicator LED
  digitalWrite(LED_BT, SerialBT.hasClient());

  // ===== Buttons =====
  if (digitalRead(BTN_ON) == LOW) {
    systemOn = true;
    SerialBT.println("System turned ON via button");
    delay(200);
  }

  if (digitalRead(BTN_OFF) == LOW) {
    systemOn = false;
    ledcWrite(pwmChannel, 0);
    SerialBT.println("System turned OFF via button");
    delay(200);
  }

  if (digitalRead(BTN_LCD) == LOW && millis() - lastLCDSwitch > 300) {
    lcdMode = (lcdMode + 1) % 3;
    lastLCDSwitch = millis();
    lcd.clear();
  }

  // ===== Bluetooth Commands =====
  if (SerialBT.available()) {
    String cmd = SerialBT.readStringUntil('\n');
    cmd.trim();
    handleBluetoothCommands(cmd);
  }

  // ===== Temperature Reading =====
  float temp = dht.readTemperature();
  if (!isnan(temp)) {
    // Exponential filter for stability
    filteredTemp = filteredTemp * 0.8f + temp * 0.2f;
  }

  // ===== Fan & LCD Update =====
  updateFanSmooth(filteredTemp);
  updateLCD(filteredTemp);

  delay(300);
}

// ================== Handle Bluetooth Commands ==================
void handleBluetoothCommands(String cmd) {
  cmd.toUpperCase();

  if (cmd == "ON") {
    systemOn = true;
    SerialBT.println("System turned ON via Bluetooth");
  } 
  else if (cmd == "OFF") {
    systemOn = false;
    ledcWrite(pwmChannel, 0);
    SerialBT.println("System turned OFF via Bluetooth");
  } 
  else if (cmd == "TEMP") {
    if (isnan(filteredTemp)) SerialBT.println("Sensor error");
    else {
      SerialBT.print("Temperature: ");
      SerialBT.print(filteredTemp, 1);
      SerialBT.println(" °C");
    }
  } 
  else if (cmd == "STATE") {
    SerialBT.print("System is currently ");
    SerialBT.println(systemOn ? "ON" : "OFF");
  } 
  else if (cmd == "HELP") {
    SerialBT.println("Commands:");
    SerialBT.println("ON - turn system on");
    SerialBT.println("OFF - turn system off");
    SerialBT.println("TEMP - show temperature");
    SerialBT.println("STATE - show on/off state");
  } 
  else {
    SerialBT.println("Unknown command. Type HELP for options.");
  }
}

// ================== Smooth Fan Control ==================
int computeDutyTarget(float temp) {
  if (!systemOn) return 0;

  if (temp <= TEMP_MIN) return 0;
  if (temp >= TEMP_MAX) return 255;

  // Linear interpolation between min and max
  float frac = (temp - TEMP_MIN) / (TEMP_MAX - TEMP_MIN);
  int target = (int)round(frac * 255.0f);

  // Stall protection + hysteresis
  if (target > 0 && target < MIN_ON_DUTY) {
    if (temp >= TEMP_MIN + HYSTERESIS) target = MIN_ON_DUTY;
    else target = 0;
  }

  return target;
}

void updateFanSmooth(float temp) {
  static bool fanWasOff = true;

  int dutyTarget = computeDutyTarget(temp);

  if (fanWasOff && dutyTarget > 0) {
    ledcWrite(pwmChannel, 255);
    delay(200);
  }
  fanWasOff = (dutyTarget == 0);

  // Exponential smoothing
  dutyCurrent += (dutyTarget - dutyCurrent) * SMOOTH_ALPHA;
  if (fabs(dutyTarget - dutyCurrent) < 0.5f) dutyCurrent = dutyTarget;

  ledcWrite(pwmChannel, (int)round(dutyCurrent));

  // Bluetooth feedback every 2 seconds
  if (millis() - lastPrint > 2000) {
    lastPrint = millis();
    int dutyPercent = map((int)round(dutyCurrent), 0, 255, 0, 100);
    SerialBT.print("Temp: ");
    SerialBT.print(temp, 1);
    SerialBT.print(" °C | Fan: ");
    SerialBT.print(dutyPercent);
    SerialBT.println("%");
  }
}

// ================== LCD Display Modes ==================
void updateLCD(float temp) {
  lcd.setCursor(0, 0);

  switch (lcdMode) {
    case 0: // Bluetooth status
      lcd.print("BT: ");
      lcd.print(SerialBT.hasClient() ? "Connected   " : "Waiting...  ");
      break;

    case 1: // System state
      lcd.print("System: ");
      lcd.print(systemOn ? "ON " : "OFF");
      break;

    case 2: // Temperature + Fan %
      if (isnan(temp)) {
        lcd.print("Sensor Error     ");
      } else {
        int dutyPercent = map((int)round(dutyCurrent), 0, 255, 0, 100);
        lcd.print("T:");
        lcd.print(temp, 1);
        lcd.print((char)223);
        lcd.print("C ");
        lcd.print("Fan:");
        lcd.print(dutyPercent);
        lcd.print("%   ");
      }
      break;
  }
}
